//// Generated from /home/noschang/NetBeansProjects/ExecutarGramatica/src/executargramatica/Linguagem.g4 by ANTLR 4.1
//package executargramatica;
//import org.antlr.v4.runtime.misc.NotNull;
//import org.antlr.v4.runtime.tree.ParseTreeListener;
//
///**
// * This interface defines a complete listener for a parse tree produced by
// * {@link LinguagemParser}.
// */
//public interface LinguagemListener extends ParseTreeListener {
//	/**
//	 * Enter a parse tree produced by {@link LinguagemParser#soma}.
//	 * @param ctx the parse tree
//	 */
//	void enterSoma(@NotNull LinguagemParser.SomaContext ctx);
//	/**
//	 * Exit a parse tree produced by {@link LinguagemParser#soma}.
//	 * @param ctx the parse tree
//	 */
//	void exitSoma(@NotNull LinguagemParser.SomaContext ctx);
//
//	/**
//	 * Enter a parse tree produced by {@link LinguagemParser#inicio}.
//	 * @param ctx the parse tree
//	 */
//	void enterInicio(@NotNull LinguagemParser.InicioContext ctx);
//	/**
//	 * Exit a parse tree produced by {@link LinguagemParser#inicio}.
//	 * @param ctx the parse tree
//	 */
//	void exitInicio(@NotNull LinguagemParser.InicioContext ctx);
//
//	/**
//	 * Enter a parse tree produced by {@link LinguagemParser#parse}.
//	 * @param ctx the parse tree
//	 */
//	void enterParse(@NotNull LinguagemParser.ParseContext ctx);
//	/**
//	 * Exit a parse tree produced by {@link LinguagemParser#parse}.
//	 * @param ctx the parse tree
//	 */
//	void exitParse(@NotNull LinguagemParser.ParseContext ctx);
//}